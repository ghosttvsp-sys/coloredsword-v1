package com.example.coloredsword;

import com.example.coloredsword.block.BlockColoredOre;
import com.example.coloredsword.item.ItemColoredGem;
import com.example.coloredsword.item.ItemColoredSword;
import com.example.coloredsword.world.WorldGenColoredOre;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Mod principal: adiciona a "Espada Colorida" (25 de dano + brilho de
 * encantamento), o "Minério Colorido" (encontrado apenas perto de lava em
 * cavernas) e a "Gema Colorida" (dropada pelo minério, usada no craft da
 * espada).
 *
 * Compatível com Minecraft Forge 1.12.2 - 14.23.5.2860
 */
@Mod(modid = ColoredSwordMod.MODID, name = ColoredSwordMod.NAME, version = ColoredSwordMod.VERSION)
public class ColoredSwordMod {

    public static final String MODID = "coloredsword";
    public static final String NAME = "Espada Colorida";
    public static final String VERSION = "1.1.0";

    /**
     * Material customizado da espada. O dano final de 25 é forçado
     * diretamente no ItemColoredSword, então o dano do material aqui
     * não influencia o resultado final.
     */
    public static final Item.ToolMaterial COLORED_SWORD_MATERIAL = EnumHelper.addToolMaterial(
            "COLORED_SWORD_MATERIAL",
            3,          // nível de harvest (como diamante)
            2000,       // durabilidade
            8.0F,       // eficiência de mineração
            3.0F,       // dano base do material (ignorado, ver ItemColoredSword)
            20          // encantabilidade
    );

    public static final double ATTACK_DAMAGE = 25.0D;

    public static Item coloredSword;
    public static Item coloredGem;
    public static Block coloredOre;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        coloredSword = new ItemColoredSword(COLORED_SWORD_MATERIAL, ATTACK_DAMAGE)
                .setRegistryName(MODID, "colored_sword")
                .setUnlocalizedName(MODID + ".colored_sword")
                .setCreativeTab(CreativeTabs.COMBAT);

        coloredGem = new ItemColoredGem()
                .setRegistryName(MODID, "colored_gem")
                .setUnlocalizedName(MODID + ".colored_gem");

        coloredOre = new BlockColoredOre()
                .setRegistryName(MODID, "colored_ore")
                .setUnlocalizedName(MODID + ".colored_ore");

        // Registra a geração de minério perto de lava em todas as dimensões do Overworld
        GameRegistry.registerWorldGenerator(new WorldGenColoredOre(), 0);
    }

    @Mod.EventBusSubscriber(modid = ColoredSwordMod.MODID)
    public static class RegistrationHandler {

        @SubscribeEvent
        public static void onItemRegister(RegistryEvent.Register<Item> event) {
            event.getRegistry().register(coloredSword);
            event.getRegistry().register(coloredGem);

            // ItemBlock do minério, para que ele possa existir no inventário/ser craftado com ele
            ItemBlock oreItemBlock = new ItemBlock(coloredOre);
            oreItemBlock.setRegistryName(coloredOre.getRegistryName());
            event.getRegistry().register(oreItemBlock);
        }

        @SubscribeEvent
        public static void onBlockRegister(RegistryEvent.Register<Block> event) {
            event.getRegistry().register(coloredOre);
        }

        @SubscribeEvent
        @SideOnly(Side.CLIENT)
        public static void onModelRegister(ModelRegistryEvent event) {
            ModelLoader.setCustomModelResourceLocation(
                    coloredSword, 0,
                    new ModelResourceLocation(coloredSword.getRegistryName(), "inventory"));

            ModelLoader.setCustomModelResourceLocation(
                    coloredGem, 0,
                    new ModelResourceLocation(coloredGem.getRegistryName(), "inventory"));

            ModelLoader.setCustomModelResourceLocation(
                    Item.getItemFromBlock(coloredOre), 0,
                    new ModelResourceLocation(coloredOre.getRegistryName(), "inventory"));
        }
    }
}
