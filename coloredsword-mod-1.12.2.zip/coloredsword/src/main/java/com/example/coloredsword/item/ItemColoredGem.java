package com.example.coloredsword.item;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

/**
 * Gema Colorida: material obtido minerando o Minério Colorido.
 * Usada como ingrediente na receita da Espada Colorida.
 */
public class ItemColoredGem extends Item {

    public ItemColoredGem() {
        this.setMaxStackSize(64);
        this.setCreativeTab(CreativeTabs.MATERIALS);
    }
}
