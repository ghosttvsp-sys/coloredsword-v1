package com.example.coloredsword.item;

import java.util.UUID;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

/**
 * Espada colorida customizada.
 *
 * - Dano de ataque fixado em 25 (independente do material passado no construtor).
 * - Sempre exibe o efeito de brilho de encantamento (enchantment glint),
 *   mesmo sem possuir nenhum encantamento real.
 */
public class ItemColoredSword extends ItemSword {

    // UUID único para o modificador de dano de ataque (não pode colidir com outros mods)
    private static final UUID ATTACK_DAMAGE_MODIFIER_UUID =
            UUID.fromString("cb3f55d3-645c-4f38-a497-9c13a33db5cf");

    private final double attackDamage;

    public ItemColoredSword(ToolMaterial material, double attackDamage) {
        super(material);
        this.attackDamage = attackDamage;
        this.setMaxStackSize(1);
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack) {
        Multimap<String, AttributeModifier> multimap = HashMultimap.create();

        if (slot == EntityEquipmentSlot.MAINHAND) {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER_UUID, "Weapon modifier", this.attackDamage, 0));

            // Mantém a velocidade de ataque padrão de uma espada
            multimap.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", -2.4D, 0));
        }

        return multimap;
    }

    /**
     * Força o item a sempre renderizar com o brilho roxo/azulado de item encantado,
     * mesmo que nenhum encantamento esteja de fato aplicado ao ItemStack.
     */
    @Override
    public boolean hasEffect(ItemStack stack) {
        return true;
    }
}
