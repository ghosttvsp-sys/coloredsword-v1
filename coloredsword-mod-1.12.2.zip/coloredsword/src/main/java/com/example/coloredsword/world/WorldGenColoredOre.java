package com.example.coloredsword.world;

import java.util.Random;

import com.example.coloredsword.ColoredSwordMod;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

/**
 * Gera veios do Minério Colorido apenas quando há lava próxima,
 * simulando cavernas profundas perto de lagos/bolsões de lava.
 *
 * Regras:
 * - Apenas no Overworld (dimensão 0)
 * - Faixa de altura Y entre 5 e 40 (camadas profundas, perto do nível clássico de lava)
 * - Só coloca o veio se houver um bloco de lava (fonte ou fluindo) num raio de 4 blocos
 */
public class WorldGenColoredOre implements IWorldGenerator {

    private static final int TENTATIVAS_POR_CHUNK = 6;
    private static final int TAMANHO_VEIO = 4;
    private static final int ALTURA_MINIMA = 5;
    private static final int ALTURA_MAXIMA = 40;
    private static final int RAIO_BUSCA_LAVA = 4;

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world,
                          IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.getDimension() == 0) { // apenas Overworld
            gerarMinerio(world, random, chunkX, chunkZ);
        }
    }

    private void gerarMinerio(World world, Random random, int chunkX, int chunkZ) {
        for (int i = 0; i < TENTATIVAS_POR_CHUNK; i++) {
            int x = chunkX * 16 + random.nextInt(16);
            int y = ALTURA_MINIMA + random.nextInt(ALTURA_MAXIMA - ALTURA_MINIMA);
            int z = chunkZ * 16 + random.nextInt(16);
            BlockPos pos = new BlockPos(x, y, z);

            if (existeLavaProxima(world, pos)) {
                IBlockState oreState = ColoredSwordMod.coloredOre.getDefaultState();
                WorldGenMinable veio = new WorldGenMinable(oreState, TAMANHO_VEIO);
                veio.generate(world, random, pos);
            }
        }
    }

    private boolean existeLavaProxima(World world, BlockPos pos) {
        for (int dx = -RAIO_BUSCA_LAVA; dx <= RAIO_BUSCA_LAVA; dx++) {
            for (int dy = -RAIO_BUSCA_LAVA; dy <= RAIO_BUSCA_LAVA; dy++) {
                for (int dz = -RAIO_BUSCA_LAVA; dz <= RAIO_BUSCA_LAVA; dz++) {
                    BlockPos alvo = pos.add(dx, dy, dz);
                    Block bloco = world.getBlockState(alvo).getBlock();
                    if (bloco == Blocks.LAVA || bloco == Blocks.FLOWING_LAVA) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
