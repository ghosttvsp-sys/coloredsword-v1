package com.example.coloredsword.block;

import java.util.Random;

import com.example.coloredsword.ColoredSwordMod;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/**
 * Minério colorido. Só é gerado naturalmente perto de lava, em camadas
 * profundas de cavernas (veja WorldGenColoredOre).
 *
 * Ao ser minerado (com picareta de ferro ou melhor), solta uma
 * Gema Colorida (ItemColoredGem), usada para craftar a Espada Colorida.
 */
public class BlockColoredOre extends Block {

    public BlockColoredOre() {
        super(Material.ROCK);
        this.setHardness(3.0F);
        this.setResistance(5.0F);
        this.setHarvestLevel("pickaxe", 2); // precisa de picareta de ferro ou superior
        this.setSoundType(SoundType.STONE);
        this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ColoredSwordMod.coloredGem;
    }

    @Override
    public int quantityDropped(Random random) {
        return 1;
    }

    @Override
    public int quantityDroppedWithBonus(int fortune, Random random) {
        int base = quantityDropped(random);
        if (fortune > 0) {
            base += random.nextInt(fortune + 1);
        }
        return Math.max(base, 1);
    }

    @Override
    public int getExpDrop(IBlockState state, IBlockAccess world, BlockPos pos, int fortune) {
        Random rand = (world instanceof World) ? ((World) world).rand : new Random();
        return 2 + rand.nextInt(4); // 2 a 5 de XP, como o minério de diamante
    }
}
